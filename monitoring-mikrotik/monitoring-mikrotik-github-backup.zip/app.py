from flask import Flask, render_template, request, redirect, url_for, session, jsonify, send_file
import socket
import time
import os
import threading
import csv
from datetime import datetime
from routeros_api import RouterOsApiPool
from openpyxl import Workbook, load_workbook
from dotenv import load_dotenv


load_dotenv()

app = Flask(__name__)
app.secret_key = os.environ["FLASK_SECRET_KEY"]



# =====================================================
# LOGIN ROUTEROS
# =====================================================

ROUTEROS_USERNAME = os.environ["ROUTEROS_USERNAME"]
ROUTEROS_PASSWORD = os.environ["ROUTEROS_PASSWORD"]
APP_USERNAME = os.environ["APP_USERNAME"]
APP_PASSWORD = os.environ["APP_PASSWORD"]


# =====================================================
# DATA ROUTER
# =====================================================

routers = {

    "CHR 1": {
        "name": "MikroTik-CHR-1",
        "ip": "192.168.56.10",
        "traffic_interface": "ether2",
        "version": "RouterOS 7.x",
        "cpu": 0,
        "memory": 0,
        "uptime": "Router Offline",
        "status": "OFFLINE",
        "interface": "-"
    },

    "CHR 2": {
        "name": "MikroTik-CHR-2",
        "ip": "192.168.56.11",
        "traffic_interface": "ether3",
        "version": "RouterOS 7.x",
        "cpu": 0,
        "memory": 0,
        "uptime": "Router Offline",
        "status": "OFFLINE",
        "interface": "-"
    }

}


# =====================================================
# TRAFFIC
# =====================================================

traffic_data = {
    "CHR 1": {
        "download": 0,
        "upload": 0
    },
    "CHR 2": {
        "download": 0,
        "upload": 0
    }
}


previous_traffic = {}
EXCEL_FILE = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "monitoring_history.xlsx"
)
excel_lock = threading.Lock()
CSV_FILE = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "monitoring_live.csv"
)
csv_lock = threading.Lock()
last_excel_save = 0

# =====================================================
# CEK PORT WINBOX
# =====================================================

def check_router(ip):

    try:

        sock = socket.socket(
            socket.AF_INET,
            socket.SOCK_STREAM
        )

        sock.settimeout(2)

        result = sock.connect_ex(
            (ip, 8291)
        )

        sock.close()

        return result == 0

    except Exception:

        return False


# =====================================================
# SIMPAN RIWAYAT KE MICROSOFT EXCEL
# =====================================================

def save_monitoring_to_excel():

    with excel_lock:

        if os.path.exists(EXCEL_FILE):
            workbook = load_workbook(EXCEL_FILE)
            sheet = workbook.active
        else:
            workbook = Workbook()
            sheet = workbook.active
            sheet.title = "Monitoring History"
            sheet.append([
                "Waktu",
                "Router",
                "IP",
                "Status",
                "CPU (%)",
                "Memory (%)",
                "Interface",
                "Download (Mbps)",
                "Upload (Mbps)"
            ])

        now = datetime.now().strftime(
            "%Y-%m-%d %H:%M:%S"
        )

        for router_name, router in routers.items():
            traffic = traffic_data[router_name]

            sheet.append([
                now,
                router_name,
                router["ip"],
                router["status"],
                router["cpu"],
                router["memory"],
                router["interface"],
                traffic["download"],
                traffic["upload"]
            ])

        workbook.save(EXCEL_FILE)


# =====================================================
# LIVE CSV UNTUK EXCEL POWER QUERY
# =====================================================

def save_monitoring_to_live_csv():

    with csv_lock:
        now = datetime.now().strftime(
            "%Y-%m-%d %H:%M:%S"
        )

        with open(
            CSV_FILE,
            "w",
            newline="",
            encoding="utf-8-sig"
        ) as csv_file:
            writer = csv.writer(csv_file)
            writer.writerow([
                "Waktu",
                "Router",
                "IP",
                "Status",
                "CPU (%)",
                "Memory (%)",
                "Interface",
                "Download (Mbps)",
                "Upload (Mbps)"
            ])

            for router_name, router in routers.items():
                traffic = traffic_data[router_name]
                writer.writerow([
                    now,
                    router_name,
                    router["ip"],
                    router["status"],
                    router["cpu"],
                    router["memory"],
                    router["interface"],
                    traffic["download"],
                    traffic["upload"]
                ])


# =====================================================
# FORMAT UPTIME
# =====================================================

def format_uptime(uptime):

    if not uptime:
        return "Router Offline"

    return str(uptime)


# =====================================================
# AMBIL DATA ROUTEROS
# =====================================================

def get_router_data(router_name, router):

    ip = router["ip"]

    try:

        # -------------------------------------------------
        # LOGIN KE ROUTEROS API
        # -------------------------------------------------

        pool = RouterOsApiPool(
            host=ip,
            username=ROUTEROS_USERNAME,
            password=ROUTEROS_PASSWORD,
            port=8728,
            plaintext_login=True
        )

        api = pool.get_api()


        # -------------------------------------------------
        # SYSTEM RESOURCE
        # -------------------------------------------------

        resource = api.get_resource(
            "/system/resource"
        )

        resource_data = resource.get()


        if not resource_data:

            pool.disconnect()

            return False


        system = resource_data[0]


        # -------------------------------------------------
        # CPU
        # -------------------------------------------------

        cpu = int(
            system.get(
                "cpu-load",
                0
            )
        )


        # -------------------------------------------------
        # MEMORY
        # -------------------------------------------------

        total_memory = int(
            system.get(
                "total-memory",
                0
            )
        )

        free_memory = int(
            system.get(
                "free-memory",
                0
            )
        )


        if total_memory > 0:

            used_memory = (
                (
                    total_memory -
                    free_memory
                )
                /
                total_memory
                *
                100
            )

        else:

            used_memory = 0


        memory = round(
            used_memory,
            1
        )


        # -------------------------------------------------
        # UPTIME
        # -------------------------------------------------

        uptime = format_uptime(
            system.get(
                "uptime",
                "Unknown"
            )
        )


        # -------------------------------------------------
        # ROUTEROS VERSION
        # -------------------------------------------------

        version = system.get(
            "version",
            "Unknown"
        )


        # -------------------------------------------------
        # IDENTITY
        # -------------------------------------------------

        identity = router["name"]

        try:

            identity_resource = api.get_resource(
                "/system/identity"
            )

            identity_data = identity_resource.get()

            if identity_data:

                identity = identity_data[0].get(
                    "name",
                    router["name"]
                )

        except Exception:

            pass



        # -------------------------------------------------
        # PILIH INTERFACE CHR
        # -------------------------------------------------

        interface_resource = api.get_resource(
            "/interface"
        )

        interfaces = interface_resource.get()

        router["interfaces"] = [
            {
                "name": item.get("name", "-"),
                "type": item.get("type", "-"),
                "running": str(item.get("running", "false")).lower() == "true",
                "disabled": str(item.get("disabled", "false")).lower() == "true",
                "rx_byte": int(item.get("rx-byte", 0)),
                "tx_byte": int(item.get("tx-byte", 0))
            }
            for item in interfaces
            if item.get("name") != "lo"
            and item.get("type", "").lower() != "loopback"
        ]

        interface_name = router.get(
            "traffic_interface",
            "ether2"
        )

        selected_interface = None

        for interface in interfaces:

            if interface.get("name") == interface_name:

                selected_interface = interface
                break


        # -------------------------------------------------
        # AMBIL TRAFFIC ASLI RX DAN TX
        # -------------------------------------------------

        download = 0
        upload = 0

        if selected_interface:

            disabled = str(
                selected_interface.get("disabled", "false")
            ).lower()

            if disabled == "true":
                raise Exception(
                    "Interface " + interface_name + " disabled"
                )

            rx_bytes = int(
                selected_interface.get("rx-byte", 0)
            )

            tx_bytes = int(
                selected_interface.get("tx-byte", 0)
            )

            current_time = time.time()

            old_data = previous_traffic.get(
                router_name
            )

            if old_data:

                time_difference = (
                    current_time - old_data["time"]
                )

                if time_difference > 0:

                    rx_difference = max(
                        0,
                        rx_bytes - old_data["rx"]
                    )

                    tx_difference = max(
                        0,
                        tx_bytes - old_data["tx"]
                    )

                    download = round(
                        (rx_difference * 8) /
                        time_difference / 1000000,
                        3
                    )

                    upload = round(
                        (tx_difference * 8) /
                        time_difference / 1000000,
                        3
                    )

            previous_traffic[router_name] = {
                "rx": rx_bytes,
                "tx": tx_bytes,
                "time": current_time
            }

        else:

            interface_name = "-"


        # -------------------------------------------------
        # SIMPAN HASIL TRAFFIC
        # -------------------------------------------------

        router["interface"] = interface_name

        traffic_data[router_name]["download"] = download

        traffic_data[router_name]["upload"] = upload
 
     

# -------------------------------------------------
        # UPDATE DATA ROUTER
        # -------------------------------------------------

        router["name"] = identity

        router["version"] = version

        router["cpu"] = cpu

        router["memory"] = memory

        router["uptime"] = uptime

        router["status"] = "ONLINE"

        router["interface"] = interface_name


        # -------------------------------------------------
        # SIMPAN TRAFFIC CHR 1
        # -------------------------------------------------

        traffic_data[router_name]["download"] = download
        traffic_data[router_name]["upload"] = upload      
        pool.disconnect()

        return True


    except Exception as e:

        print()
        print("====================================")
        print(
            "GAGAL MENGAMBIL DATA:",
            router_name
        )
        print(
            "IP:",
            ip
        )
        print(
            "ERROR:",
            str(e)
        )
        print("====================================")


        router["status"] = "OFFLINE"

        router["cpu"] = 0

        router["memory"] = 0

        router["uptime"] = "Router Offline"

        router["interface"] = "-"


        return False


# =====================================================
# UPDATE SEMUA ROUTER
# =====================================================

def update_router_status():
    global last_excel_save

    for router_name, router in routers.items():

        get_router_data(
            router_name,
            router
        )

    current_time = time.time()

    if current_time - last_excel_save >= 5:
        save_monitoring_to_excel()
        save_monitoring_to_live_csv()
        last_excel_save = current_time



# =====================================================
# LOGIN
# =====================================================

@app.route(
    "/login",
    methods=["GET", "POST"]
)
def login():

    if request.method == "POST":

        username = request.form.get(
            "username"
        )

        password = request.form.get(
            "password"
        )


        if (
            username == APP_USERNAME
            and
            password == APP_PASSWORD
        ):

            session["logged_in"] = True

            return redirect(
                url_for("dashboard")
            )


        return render_template(
            "login.html",
            error="Username atau password salah!"
        )


    return render_template(
        "login.html"
    )


# =====================================================
# LOGOUT
# =====================================================

@app.route(
    "/logout",
    methods=["GET"]
)
def logout():

    session.clear()

    return redirect(
        url_for("login")
    )


# =====================================================
# DASHBOARD
# =====================================================

@app.route(
    "/",
    methods=["GET"]
)
def dashboard():

    if not session.get(
        "logged_in"
    ):

        return redirect(
            url_for("login")
        )


    update_router_status()


    return render_template(
        "index.html",
        router=routers["CHR 1"],
        traffic=traffic_data,
        routers=routers
    )


# =====================================================
# UPDATE IP CHR 1
# =====================================================

@app.route(
    "/update-ip",
    methods=["POST"]
)
def update_ip():

    if not session.get(
        "logged_in"
    ):

        return redirect(
            url_for("login")
        )


    new_ip = request.form.get(
        "ip",
        ""
    ).strip()


    if new_ip:

        routers["CHR 1"]["ip"] = new_ip


    return redirect(
        url_for("dashboard")
    )



# =====================================================
# HALAMAN PENJELASAN
# =====================================================

# =====================================================
# HALAMAN CHR 1
# =====================================================

@app.route(
    "/chr1",
    methods=["GET"]
)
def chr1():

    if not session.get(
        "logged_in"
    ):

        return redirect(
            url_for("login")
        )

    update_router_status()

    return render_template(
        "router1.html",
        router=routers["CHR 1"]
    )


# =====================================================
# HALAMAN CHR 2
# =====================================================

@app.route(
    "/chr2",
    methods=["GET"]
)
def chr2():

    if not session.get(
        "logged_in"
    ):

        return redirect(
            url_for("login")
        )

    update_router_status()

    return render_template(
        "router2.html",
        router=routers["CHR 2"]
    )

@app.route(
    "/penjelasan",
    methods=["GET"]
)
def penjelasan():

    if not session.get(
        "logged_in"
    ):

        return redirect(
            url_for("login")
        )


    update_router_status()


    return render_template(
        "penjelasan.html",
        router=routers["CHR 1"]
    )


# =====================================================
# API STATUS
# =====================================================

@app.route(
    "/api/status",
    methods=["GET"]
)
def api_status():

    update_router_status()


    return jsonify({
    "routers": routers,
    "router": routers["CHR 1"],
    "traffic": traffic_data,
    "traffic_chr1": traffic_data["CHR 1"],
    "traffic_chr2": traffic_data["CHR 2"]
})


# =====================================================
# UNDUH RIWAYAT MICROSOFT EXCEL
# =====================================================

@app.route(
    "/export/excel",
    methods=["GET"]
)
def export_excel():

    if not session.get(
        "logged_in"
    ):
        return redirect(
            url_for("login")
        )

    save_monitoring_to_excel()

    return send_file(
        EXCEL_FILE,
        as_attachment=True,
        download_name="monitoring_history.xlsx",
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )


@app.route(
    "/export/csv",
    methods=["GET"]
)
def export_csv():

    if not session.get(
        "logged_in"
    ):
        return redirect(
            url_for("login")
        )

    save_monitoring_to_live_csv()

    return send_file(
        CSV_FILE,
        as_attachment=True,
        download_name="monitoring_live.csv",
        mimetype="text/csv"
    )

# =====================================================
# JALANKAN SERVER
# =====================================================

if __name__ == "__main__":

    app.run(
        host="0.0.0.0",
        port=5000,
        debug=True
    )